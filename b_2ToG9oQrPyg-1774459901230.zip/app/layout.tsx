import type { Metadata, Viewport } from 'next'
import { Inter, Space_Grotesk } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ 
  subsets: ["latin"],
  variable: "--font-inter"
});

const spaceGrotesk = Space_Grotesk({ 
  subsets: ["latin"],
  variable: "--font-space-grotesk"
});

export const metadata: Metadata = {
  title: 'DSTICKET - Sistema de Venda de Ingressos',
  description: 'Compre ingressos de cinema online. Filmes de acao, romance, terror, comedia e muito mais!',
  keywords: ['cinema', 'ingressos', 'filmes', 'bilheteria', 'DSTICKET'],
}

export const viewport: Viewport = {
  themeColor: '#f5a623',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="pt-BR">
      <body className={`${inter.variable} ${spaceGrotesk.variable} font-sans antialiased`}>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
