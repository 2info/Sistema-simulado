"use client"

import { use, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ArrowLeft, Clock, Star, Ticket, Minus, Plus, ShoppingCart, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/header"
import { useStore } from "@/lib/store"
import { categoryLabels, categoryColors } from "@/lib/data"

interface PageProps {
  params: Promise<{ id: string }>
}

export default function MoviePage({ params }: PageProps) {
  const { id } = use(params)
  const { movies, addToCart } = useStore()
  const movie = movies.find((m) => m.id === id)

  const [selectedSession, setSelectedSession] = useState<string | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [addedToCart, setAddedToCart] = useState(false)

  if (!movie) {
    notFound()
  }

  const handleAddToCart = () => {
    if (!selectedSession) return
    addToCart(movie, selectedSession, quantity)
    setAddedToCart(true)
    setTimeout(() => setAddedToCart(false), 2000)
  }

  const total = movie.price * quantity

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="px-4 py-8">
        <div className="mx-auto max-w-6xl">
          {/* Back Button */}
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-6">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar aos filmes
            </Button>
          </Link>

          <div className="grid gap-8 lg:grid-cols-3">
            {/* Movie Poster */}
            <div className="lg:col-span-1">
              <div className="relative aspect-[2/3] overflow-hidden rounded-xl border border-border">
                <Image
                  src={movie.poster}
                  alt={movie.title}
                  fill
                  className="object-cover"
                  priority
                />
                <Badge
                  className={`absolute right-3 top-3 ${categoryColors[movie.category]} text-foreground border-0`}
                >
                  {categoryLabels[movie.category]}
                </Badge>
              </div>
            </div>

            {/* Movie Details */}
            <div className="lg:col-span-2 space-y-6">
              <div>
                <h1 className="mb-3 text-3xl font-bold text-foreground md:text-4xl">
                  {movie.title}
                </h1>
                <div className="mb-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    {movie.duration}
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-primary text-primary" />
                    {movie.rating}
                  </span>
                  <span className="flex items-center gap-1">
                    <Ticket className="h-4 w-4" />
                    {movie.ticketsSold.toLocaleString()} ingressos vendidos
                  </span>
                </div>
                <p className="text-lg leading-relaxed text-muted-foreground">
                  {movie.description}
                </p>
              </div>

              {/* Session Selection */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Escolha sua sessao</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-3">
                    {movie.sessions.map((session) => (
                      <Button
                        key={session}
                        variant={selectedSession === session ? "default" : "outline"}
                        onClick={() => setSelectedSession(session)}
                        className="min-w-[80px]"
                      >
                        {session}
                      </Button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Quantity and Purchase */}
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Quantidade de ingressos</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center gap-4">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                    >
                      <Minus className="h-4 w-4" />
                    </Button>
                    <span className="min-w-[60px] text-center text-2xl font-bold text-card-foreground">
                      {quantity}
                    </span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setQuantity(Math.min(10, quantity + 1))}
                      disabled={quantity >= 10}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>

                  <div className="rounded-lg border border-border bg-muted p-4">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Preco unitario:</span>
                      <span className="font-medium text-card-foreground">R$ {movie.price.toFixed(2)}</span>
                    </div>
                    <div className="mt-2 flex items-center justify-between border-t border-border pt-2">
                      <span className="text-lg font-semibold text-card-foreground">Total:</span>
                      <span className="text-2xl font-bold text-primary">R$ {total.toFixed(2)}</span>
                    </div>
                  </div>

                  <Button
                    onClick={handleAddToCart}
                    disabled={!selectedSession || addedToCart}
                    className="w-full"
                    size="lg"
                  >
                    {addedToCart ? (
                      <>
                        <Check className="mr-2 h-5 w-5" />
                        Adicionado ao carrinho!
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="mr-2 h-5 w-5" />
                        Adicionar ao carrinho
                      </>
                    )}
                  </Button>

                  {!selectedSession && (
                    <p className="text-center text-sm text-muted-foreground">
                      Selecione uma sessao para continuar
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
