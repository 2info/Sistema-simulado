"use client"

import { useEffect } from "react"
import { Search, Users, Ticket, TrendingUp } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Header } from "@/components/header"
import { MovieCard } from "@/components/movie-card"
import { CategoryFilter } from "@/components/category-filter"
import { HeroDecorations } from "@/components/cinema-decorations"
import { useStore } from "@/lib/store"
import { useState } from "react"

export default function HomePage() {
  const { movies, selectedCategory, analytics, incrementVisitors } = useStore()
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    incrementVisitors()
  }, [incrementVisitors])

  const filteredMovies = movies.filter((movie) => {
    const matchesCategory = !selectedCategory || movie.category === selectedCategory
    const matchesSearch = movie.title.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-border bg-gradient-to-b from-primary/10 via-background to-background px-4 py-12 md:py-20">
        <HeroDecorations />
        <div className="relative mx-auto max-w-7xl">
          <div className="text-center">
            <h1 className="mb-4 text-4xl font-bold tracking-tight text-foreground md:text-6xl">
              <span className="text-primary">DS</span>TICKET
            </h1>
            <p className="mx-auto mb-8 max-w-2xl text-lg text-muted-foreground">
              Sua experiencia cinematografica comeca aqui. Escolha seu filme, selecione a sessao e garanta seu ingresso.
            </p>
            
            {/* Stats */}
            <div className="mx-auto mb-8 grid max-w-3xl grid-cols-2 gap-4 md:grid-cols-4">
              <div className="rounded-xl border border-border bg-card p-4">
                <Users className="mx-auto mb-2 h-6 w-6 text-primary" />
                <p className="text-2xl font-bold text-card-foreground">{analytics.totalVisitors.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Visitantes</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-4">
                <Ticket className="mx-auto mb-2 h-6 w-6 text-primary" />
                <p className="text-2xl font-bold text-card-foreground">{analytics.totalTicketsSold.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Ingressos Vendidos</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-4">
                <TrendingUp className="mx-auto mb-2 h-6 w-6 text-primary" />
                <p className="text-2xl font-bold text-card-foreground">R$ {(analytics.totalRevenue / 1000).toFixed(0)}K</p>
                <p className="text-xs text-muted-foreground">Receita Total</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-4">
                <Search className="mx-auto mb-2 h-6 w-6 text-primary" />
                <p className="text-2xl font-bold text-card-foreground">{movies.length}</p>
                <p className="text-xs text-muted-foreground">Filmes em Cartaz</p>
              </div>
            </div>

            {/* Search */}
            <div className="mx-auto max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Buscar filmes..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Movies Section */}
      <section className="px-4 py-8 md:py-12">
        <div className="mx-auto max-w-7xl">
          <div className="mb-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <h2 className="text-2xl font-bold text-foreground">
              Filmes em Cartaz
            </h2>
            <CategoryFilter />
          </div>

          {filteredMovies.length > 0 ? (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {filteredMovies.map((movie) => (
                <MovieCard key={movie.id} movie={movie} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <Search className="mb-4 h-12 w-12 text-muted-foreground" />
              <h3 className="mb-2 text-lg font-medium text-foreground">
                Nenhum filme encontrado
              </h3>
              <p className="text-sm text-muted-foreground">
                Tente buscar por outro termo ou categoria
              </p>
            </div>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card px-4 py-8">
        <div className="mx-auto max-w-7xl text-center">
          <p className="text-sm text-muted-foreground">
            2026 DSTICKET. Sistema de venda de ingressos de cinema.
          </p>
        </div>
      </footer>
    </div>
  )
}
