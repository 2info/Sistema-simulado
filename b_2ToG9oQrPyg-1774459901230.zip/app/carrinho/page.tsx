"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { ArrowLeft, Trash2, ShoppingCart, CreditCard, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Header } from "@/components/header"
import { useStore } from "@/lib/store"

export default function CartPage() {
  const { cart, removeFromCart, completePurchase, clearCart } = useStore()
  const [buyerName, setBuyerName] = useState("")
  const [buyerEmail, setBuyerEmail] = useState("")
  const [purchaseComplete, setPurchaseComplete] = useState(false)

  const total = cart.reduce(
    (acc, item) => acc + item.movie.price * item.quantity,
    0
  )
  const totalItems = cart.reduce((acc, item) => acc + item.quantity, 0)

  const handlePurchase = () => {
    if (!buyerName || !buyerEmail || cart.length === 0) return
    completePurchase(buyerName, buyerEmail)
    setPurchaseComplete(true)
    setBuyerName("")
    setBuyerEmail("")
  }

  if (purchaseComplete) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="flex min-h-[60vh] flex-col items-center justify-center px-4 py-12">
          <div className="mx-auto max-w-md text-center">
            <div className="mb-6 flex h-20 w-20 mx-auto items-center justify-center rounded-full bg-primary">
              <Check className="h-10 w-10 text-primary-foreground" />
            </div>
            <h1 className="mb-4 text-3xl font-bold text-foreground">
              Compra realizada com sucesso!
            </h1>
            <p className="mb-8 text-muted-foreground">
              Seus ingressos foram adquiridos. Voce recebera um e-mail com a confirmacao e os detalhes da compra.
            </p>
            <Link href="/">
              <Button size="lg">
                Continuar comprando
              </Button>
            </Link>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="px-4 py-8">
        <div className="mx-auto max-w-4xl">
          <Link href="/">
            <Button variant="ghost" size="sm" className="mb-6">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar aos filmes
            </Button>
          </Link>

          <h1 className="mb-8 text-3xl font-bold text-foreground">
            Seu Carrinho
          </h1>

          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center">
              <ShoppingCart className="mb-4 h-16 w-16 text-muted-foreground" />
              <h2 className="mb-2 text-xl font-medium text-foreground">
                Seu carrinho esta vazio
              </h2>
              <p className="mb-6 text-muted-foreground">
                Adicione filmes ao seu carrinho para continuar
              </p>
              <Link href="/">
                <Button>Ver filmes em cartaz</Button>
              </Link>
            </div>
          ) : (
            <div className="grid gap-8 lg:grid-cols-3">
              {/* Cart Items */}
              <div className="lg:col-span-2 space-y-4">
                {cart.map((item) => (
                  <Card key={`${item.movie.id}-${item.session}`} className="border-border bg-card">
                    <CardContent className="p-4">
                      <div className="flex gap-4">
                        <div className="relative h-24 w-16 flex-shrink-0 overflow-hidden rounded-lg">
                          <Image
                            src={item.movie.poster}
                            alt={item.movie.title}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div className="flex flex-1 flex-col justify-between">
                          <div>
                            <h3 className="font-semibold text-card-foreground">
                              {item.movie.title}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              Sessao: {item.session} | {item.quantity} ingresso(s)
                            </p>
                          </div>
                          <p className="text-lg font-bold text-primary">
                            R$ {(item.movie.price * item.quantity).toFixed(2)}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeFromCart(item.movie.id, item.session)}
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                <Button
                  variant="outline"
                  onClick={clearCart}
                  className="w-full"
                >
                  Limpar carrinho
                </Button>
              </div>

              {/* Checkout */}
              <div className="lg:col-span-1">
                <Card className="sticky top-24 border-border bg-card">
                  <CardHeader>
                    <CardTitle className="text-card-foreground">Finalizar compra</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Nome completo</Label>
                      <Input
                        id="name"
                        value={buyerName}
                        onChange={(e) => setBuyerName(e.target.value)}
                        placeholder="Seu nome"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">E-mail</Label>
                      <Input
                        id="email"
                        type="email"
                        value={buyerEmail}
                        onChange={(e) => setBuyerEmail(e.target.value)}
                        placeholder="seu@email.com"
                      />
                    </div>

                    <div className="rounded-lg border border-border bg-muted p-4 space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Ingressos:</span>
                        <span className="text-card-foreground">{totalItems}</span>
                      </div>
                      <div className="flex items-center justify-between border-t border-border pt-2">
                        <span className="font-semibold text-card-foreground">Total:</span>
                        <span className="text-2xl font-bold text-primary">
                          R$ {total.toFixed(2)}
                        </span>
                      </div>
                    </div>

                    <Button
                      onClick={handlePurchase}
                      disabled={!buyerName || !buyerEmail}
                      className="w-full"
                      size="lg"
                    >
                      <CreditCard className="mr-2 h-5 w-5" />
                      Finalizar compra
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
