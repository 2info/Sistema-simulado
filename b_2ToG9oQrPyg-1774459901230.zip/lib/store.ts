"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import { movies as initialMovies, initialAnalytics, type Movie, type Analytics, type TicketPurchase } from "./data"

interface StoreState {
  movies: Movie[]
  analytics: Analytics
  selectedCategory: string | null
  cart: { movie: Movie; session: string; quantity: number }[]
  
  // Actions
  setSelectedCategory: (category: string | null) => void
  addToCart: (movie: Movie, session: string, quantity: number) => void
  removeFromCart: (movieId: string, session: string) => void
  clearCart: () => void
  completePurchase: (buyerName: string, buyerEmail: string) => void
  incrementVisitors: () => void
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      movies: initialMovies,
      analytics: initialAnalytics,
      selectedCategory: null,
      cart: [],

      setSelectedCategory: (category) => set({ selectedCategory: category }),

      addToCart: (movie, session, quantity) => {
        const cart = get().cart
        const existingIndex = cart.findIndex(
          (item) => item.movie.id === movie.id && item.session === session
        )
        
        if (existingIndex >= 0) {
          const newCart = [...cart]
          newCart[existingIndex].quantity += quantity
          set({ cart: newCart })
        } else {
          set({ cart: [...cart, { movie, session, quantity }] })
        }
      },

      removeFromCart: (movieId, session) => {
        set({
          cart: get().cart.filter(
            (item) => !(item.movie.id === movieId && item.session === session)
          ),
        })
      },

      clearCart: () => set({ cart: [] }),

      completePurchase: (buyerName, buyerEmail) => {
        const { cart, movies, analytics } = get()
        
        const newPurchases: TicketPurchase[] = cart.map((item, index) => ({
          id: `p${Date.now()}-${index}`,
          movieId: item.movie.id,
          movieTitle: item.movie.title,
          session: item.session,
          quantity: item.quantity,
          total: item.movie.price * item.quantity,
          buyerName,
          buyerEmail,
          purchaseDate: new Date(),
        }))

        const totalTickets = cart.reduce((acc, item) => acc + item.quantity, 0)
        const totalRevenue = cart.reduce(
          (acc, item) => acc + item.movie.price * item.quantity,
          0
        )

        // Update movie ticket counts
        const updatedMovies = movies.map((movie) => {
          const cartItem = cart.find((item) => item.movie.id === movie.id)
          if (cartItem) {
            return { ...movie, ticketsSold: movie.ticketsSold + cartItem.quantity }
          }
          return movie
        })

        set({
          movies: updatedMovies,
          cart: [],
          analytics: {
            ...analytics,
            totalTicketsSold: analytics.totalTicketsSold + totalTickets,
            totalRevenue: analytics.totalRevenue + totalRevenue,
            recentPurchases: [...newPurchases, ...analytics.recentPurchases].slice(0, 10),
          },
        })
      },

      incrementVisitors: () => {
        const { analytics } = get()
        set({
          analytics: {
            ...analytics,
            totalVisitors: analytics.totalVisitors + 1,
          },
        })
      },
    }),
    {
      name: "dsticket-store",
    }
  )
)
