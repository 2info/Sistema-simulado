export type Category =
  | "acao"
  | "romance"
  | "terror"
  | "suspense"
  | "comedia"
  | "noticiarios"
  | "documentario"
  | "animacao"
  | "aventura"

export interface Movie {
  id: string
  title: string
  category: Category
  description: string
  duration: string
  rating: string
  poster: string
  price: number
  sessions: string[]
  ticketsSold: number
}

export interface TicketPurchase {
  id: string
  movieId: string
  movieTitle: string
  session: string
  quantity: number
  total: number
  buyerName: string
  buyerEmail: string
  purchaseDate: Date
}

export interface Analytics {
  totalVisitors: number
  totalTicketsSold: number
  totalRevenue: number
  visitorsByDay: { date: string; visitors: number }[]
  salesByCategory: { category: string; sales: number }[]
  recentPurchases: TicketPurchase[]
}

export const categoryLabels: Record<Category, string> = {
  acao: "Acao",
  romance: "Romance",
  terror: "Terror",
  suspense: "Suspense",
  comedia: "Comedia",
  noticiarios: "Noticiarios",
  documentario: "Documentario",
  animacao: "Animacao",
  aventura: "Aventura",
}

export const categoryColors: Record<Category, string> = {
  acao: "bg-red-600",
  romance: "bg-pink-500",
  terror: "bg-gray-800",
  suspense: "bg-amber-700",
  comedia: "bg-yellow-500",
  noticiarios: "bg-blue-600",
  documentario: "bg-green-600",
  animacao: "bg-purple-500",
  aventura: "bg-orange-500",
}

export const movies: Movie[] = [
  {
    id: "1",
    title: "Furia Veloz",
    category: "acao",
    description: "Um ex-piloto de corrida e enfrenta uma organizacao criminosa em perseguicoes de tirar o folego.",
    duration: "2h 15min",
    rating: "14+",
    poster: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop",
    price: 32.00,
    sessions: ["14:00", "16:30", "19:00", "21:30"],
    ticketsSold: 847
  },
  {
    id: "2",
    title: "Coracao em Chamas",
    category: "romance",
    description: "Dois estranhos se encontram em Paris e descobrem que o amor pode mudar tudo.",
    duration: "1h 58min",
    rating: "12+",
    poster: "https://images.unsplash.com/photo-1518676590629-3dcbd9c5a5c9?w=400&h=600&fit=crop",
    price: 28.00,
    sessions: ["15:00", "17:30", "20:00"],
    ticketsSold: 623
  },
  {
    id: "3",
    title: "Sombras do Passado",
    category: "terror",
    description: "Uma familia se muda para uma mansao antiga e descobre segredos macabros.",
    duration: "1h 45min",
    rating: "18+",
    poster: "https://images.unsplash.com/photo-1509248961895-b4a67b8c9cb9?w=400&h=600&fit=crop",
    price: 30.00,
    sessions: ["21:00", "23:30"],
    ticketsSold: 512
  },
  {
    id: "4",
    title: "O Enigma Final",
    category: "suspense",
    description: "Um detetive aposentado recebe pistas de um serial killer que ele nunca conseguiu prender.",
    duration: "2h 05min",
    rating: "16+",
    poster: "https://images.unsplash.com/photo-1478720568477-152d9b164e26?w=400&h=600&fit=crop",
    price: 30.00,
    sessions: ["16:00", "18:30", "21:00"],
    ticketsSold: 734
  },
  {
    id: "5",
    title: "Confusoes em Familia",
    category: "comedia",
    description: "Uma reuniao de familia se transforma em uma serie de situacoes hilarias.",
    duration: "1h 42min",
    rating: "Livre",
    poster: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400&h=600&fit=crop",
    price: 26.00,
    sessions: ["14:00", "16:00", "18:00", "20:00"],
    ticketsSold: 956
  },
  {
    id: "6",
    title: "Planeta em Crise",
    category: "documentario",
    description: "Um documentario impactante sobre as mudancas climaticas e seus efeitos.",
    duration: "1h 30min",
    rating: "Livre",
    poster: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?w=400&h=600&fit=crop",
    price: 22.00,
    sessions: ["15:00", "17:00", "19:00"],
    ticketsSold: 298
  },
  {
    id: "7",
    title: "Aventuras de Luna",
    category: "animacao",
    description: "Uma gatinha corajosa embarca em uma jornada magica para salvar seu reino.",
    duration: "1h 35min",
    rating: "Livre",
    poster: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=400&h=600&fit=crop",
    price: 24.00,
    sessions: ["13:00", "15:00", "17:00"],
    ticketsSold: 1123
  },
  {
    id: "8",
    title: "A Grande Exploracao",
    category: "aventura",
    description: "Arqueologos descobrem um mapa antigo que leva a um tesouro perdido.",
    duration: "2h 20min",
    rating: "12+",
    poster: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400&h=600&fit=crop",
    price: 32.00,
    sessions: ["14:30", "17:00", "19:30", "22:00"],
    ticketsSold: 678
  },
  {
    id: "9",
    title: "Noticias ao Vivo",
    category: "noticiarios",
    description: "Um especial sobre os maiores acontecimentos do ano em formato cinematografico.",
    duration: "1h 20min",
    rating: "Livre",
    poster: "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=400&h=600&fit=crop",
    price: 18.00,
    sessions: ["10:00", "12:00", "14:00"],
    ticketsSold: 156
  },
  {
    id: "10",
    title: "Impacto Zero",
    category: "acao",
    description: "Agentes especiais devem impedir um ataque terrorista em tempo recorde.",
    duration: "2h 10min",
    rating: "16+",
    poster: "https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=400&h=600&fit=crop",
    price: 34.00,
    sessions: ["15:00", "17:30", "20:00", "22:30"],
    ticketsSold: 892
  },
  {
    id: "11",
    title: "Amor de Verao",
    category: "romance",
    description: "Dois jovens se conhecem nas ferias e vivem um romance inesquecivel.",
    duration: "1h 50min",
    rating: "12+",
    poster: "https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?w=400&h=600&fit=crop",
    price: 26.00,
    sessions: ["14:00", "16:30", "19:00"],
    ticketsSold: 445
  },
  {
    id: "12",
    title: "Reino Encantado",
    category: "animacao",
    description: "Uma princesa rebelde descobre poderes magicos e salva seu reino.",
    duration: "1h 40min",
    rating: "Livre",
    poster: "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=400&h=600&fit=crop",
    price: 24.00,
    sessions: ["13:30", "15:30", "17:30"],
    ticketsSold: 987
  },
]

export const initialAnalytics: Analytics = {
  totalVisitors: 15847,
  totalTicketsSold: movies.reduce((acc, m) => acc + m.ticketsSold, 0),
  totalRevenue: movies.reduce((acc, m) => acc + (m.ticketsSold * m.price), 0),
  visitorsByDay: [
    { date: "Seg", visitors: 1234 },
    { date: "Ter", visitors: 1567 },
    { date: "Qua", visitors: 1823 },
    { date: "Qui", visitors: 2156 },
    { date: "Sex", visitors: 2987 },
    { date: "Sab", visitors: 3245 },
    { date: "Dom", visitors: 2835 },
  ],
  salesByCategory: [
    { category: "Acao", sales: 1739 },
    { category: "Romance", sales: 1068 },
    { category: "Terror", sales: 512 },
    { category: "Suspense", sales: 734 },
    { category: "Comedia", sales: 956 },
    { category: "Documentario", sales: 298 },
    { category: "Animacao", sales: 2110 },
    { category: "Aventura", sales: 678 },
    { category: "Noticiarios", sales: 156 },
  ],
  recentPurchases: [
    {
      id: "p1",
      movieId: "7",
      movieTitle: "Aventuras de Luna",
      session: "15:00",
      quantity: 4,
      total: 96.00,
      buyerName: "Maria Silva",
      buyerEmail: "maria@email.com",
      purchaseDate: new Date(Date.now() - 1000 * 60 * 5)
    },
    {
      id: "p2",
      movieId: "1",
      movieTitle: "Furia Veloz",
      session: "21:30",
      quantity: 2,
      total: 64.00,
      buyerName: "Joao Santos",
      buyerEmail: "joao@email.com",
      purchaseDate: new Date(Date.now() - 1000 * 60 * 15)
    },
    {
      id: "p3",
      movieId: "5",
      movieTitle: "Confusoes em Familia",
      session: "18:00",
      quantity: 3,
      total: 78.00,
      buyerName: "Ana Costa",
      buyerEmail: "ana@email.com",
      purchaseDate: new Date(Date.now() - 1000 * 60 * 30)
    },
  ]
}
