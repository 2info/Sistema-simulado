"use client"

import { Button } from "@/components/ui/button"
import { useStore } from "@/lib/store"
import { categoryLabels, type Category } from "@/lib/data"
import { 
  Sword, 
  Heart, 
  Ghost, 
  Search, 
  Laugh, 
  Newspaper, 
  FileText, 
  Sparkles, 
  Mountain 
} from "lucide-react"

const categoryIcons: Record<Category, React.ReactNode> = {
  acao: <Sword className="h-4 w-4" />,
  romance: <Heart className="h-4 w-4" />,
  terror: <Ghost className="h-4 w-4" />,
  suspense: <Search className="h-4 w-4" />,
  comedia: <Laugh className="h-4 w-4" />,
  noticiarios: <Newspaper className="h-4 w-4" />,
  documentario: <FileText className="h-4 w-4" />,
  animacao: <Sparkles className="h-4 w-4" />,
  aventura: <Mountain className="h-4 w-4" />,
}

export function CategoryFilter() {
  const { selectedCategory, setSelectedCategory } = useStore()

  const categories = Object.keys(categoryLabels) as Category[]

  return (
    <div className="flex flex-wrap items-center gap-2">
      <Button
        variant={selectedCategory === null ? "default" : "outline"}
        size="sm"
        onClick={() => setSelectedCategory(null)}
        className="rounded-full"
      >
        Todos
      </Button>
      {categories.map((category) => (
        <Button
          key={category}
          variant={selectedCategory === category ? "default" : "outline"}
          size="sm"
          onClick={() => setSelectedCategory(category)}
          className="flex items-center gap-2 rounded-full"
        >
          {categoryIcons[category]}
          <span className="hidden sm:inline">{categoryLabels[category]}</span>
        </Button>
      ))}
    </div>
  )
}
