"use client"

export function FilmStrip() {
  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 h-8 overflow-hidden opacity-20">
      <div className="flex animate-marquee">
        {Array.from({ length: 20 }).map((_, i) => (
          <div key={i} className="mx-1 flex h-8 w-12 items-center justify-center border-x-2 border-primary bg-background">
            <div className="h-4 w-8 rounded bg-primary/30" />
          </div>
        ))}
      </div>
    </div>
  )
}

export function Popcorn({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M25 45L35 90H65L75 45"
        fill="currentColor"
        className="text-secondary"
      />
      <path
        d="M20 45C20 45 25 20 50 20C75 20 80 45 80 45"
        fill="currentColor"
        className="text-primary"
      />
      <circle cx="35" cy="35" r="10" fill="currentColor" className="text-primary" />
      <circle cx="50" cy="28" r="12" fill="currentColor" className="text-primary" />
      <circle cx="65" cy="35" r="10" fill="currentColor" className="text-primary" />
      <circle cx="42" cy="40" r="8" fill="currentColor" className="text-primary" />
      <circle cx="58" cy="40" r="8" fill="currentColor" className="text-primary" />
    </svg>
  )
}

export function Clapperboard({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect x="15" y="35" width="70" height="50" rx="4" fill="currentColor" className="text-card" />
      <path d="M15 35L25 15H85L75 35H15Z" fill="currentColor" className="text-primary" />
      <rect x="30" y="15" width="8" height="20" transform="rotate(-15 30 15)" fill="currentColor" className="text-background" />
      <rect x="50" y="12" width="8" height="20" transform="rotate(-15 50 12)" fill="currentColor" className="text-background" />
      <rect x="70" y="9" width="8" height="20" transform="rotate(-15 70 9)" fill="currentColor" className="text-background" />
    </svg>
  )
}

export function FilmReel({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="4" className="text-primary" />
      <circle cx="50" cy="50" r="30" stroke="currentColor" strokeWidth="2" className="text-muted" />
      <circle cx="50" cy="50" r="8" fill="currentColor" className="text-primary" />
      <circle cx="50" cy="25" r="6" fill="currentColor" className="text-secondary" />
      <circle cx="50" cy="75" r="6" fill="currentColor" className="text-secondary" />
      <circle cx="25" cy="50" r="6" fill="currentColor" className="text-secondary" />
      <circle cx="75" cy="50" r="6" fill="currentColor" className="text-secondary" />
    </svg>
  )
}

export function HeroDecorations() {
  return (
    <>
      <Popcorn className="absolute -left-4 top-20 h-24 w-24 rotate-12 opacity-10 md:h-32 md:w-32 md:opacity-20" />
      <Clapperboard className="absolute -right-4 bottom-10 h-20 w-20 -rotate-12 opacity-10 md:h-28 md:w-28 md:opacity-20" />
      <FilmReel className="absolute right-20 top-10 hidden h-16 w-16 animate-spin-slow opacity-10 md:block" />
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent" />
    </>
  )
}
