"use client"

import Image from "next/image"
import Link from "next/link"
import { Clock, Star, Ticket } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { type Movie, categoryLabels, categoryColors } from "@/lib/data"

interface MovieCardProps {
  movie: Movie
}

export function MovieCard({ movie }: MovieCardProps) {
  return (
    <Link href={`/filme/${movie.id}`}>
      <Card className="group overflow-hidden border-border bg-card transition-all duration-300 hover:border-primary hover:shadow-lg hover:shadow-primary/10">
        <div className="relative aspect-[2/3] overflow-hidden">
          <Image
            src={movie.poster}
            alt={movie.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent" />
          <Badge
            className={`absolute right-2 top-2 ${categoryColors[movie.category]} text-foreground border-0`}
          >
            {categoryLabels[movie.category]}
          </Badge>
          <div className="absolute bottom-0 left-0 right-0 p-4">
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {movie.duration}
              </span>
              <span className="flex items-center gap-1">
                <Star className="h-3 w-3 fill-primary text-primary" />
                {movie.rating}
              </span>
            </div>
          </div>
        </div>
        <CardContent className="p-4">
          <h3 className="mb-2 line-clamp-1 text-lg font-semibold text-card-foreground transition-colors group-hover:text-primary">
            {movie.title}
          </h3>
          <p className="mb-3 line-clamp-2 text-sm text-muted-foreground">
            {movie.description}
          </p>
          <div className="flex items-center justify-between">
            <span className="text-lg font-bold text-primary">
              R$ {movie.price.toFixed(2)}
            </span>
            <span className="flex items-center gap-1 text-xs text-muted-foreground">
              <Ticket className="h-3 w-3" />
              {movie.ticketsSold} vendidos
            </span>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}
