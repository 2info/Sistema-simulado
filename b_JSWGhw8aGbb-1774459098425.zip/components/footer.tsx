import Link from 'next/link'
import { Scissors, MapPin, Phone, Mail, Clock, Instagram, Facebook } from 'lucide-react'

export function Footer() {
  return (
    <footer className="border-t border-border bg-sidebar text-sidebar-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="space-y-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
                <Scissors className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="font-serif text-xl font-bold">Malik&apos;s Hair</span>
            </Link>
            <p className="text-sm text-sidebar-foreground/70">
              Transformando vidas através da beleza desde 2015. Sua satisfação é nossa prioridade.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-sidebar-foreground/70 transition-colors hover:text-sidebar-primary">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-sidebar-foreground/70 transition-colors hover:text-sidebar-primary">
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Links */}
          <div className="space-y-4">
            <h3 className="font-semibold">Links Rápidos</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/catalogo" className="text-sidebar-foreground/70 transition-colors hover:text-sidebar-primary">
                  Catálogo de Serviços
                </Link>
              </li>
              <li>
                <Link href="/equipe" className="text-sidebar-foreground/70 transition-colors hover:text-sidebar-primary">
                  Nossa Equipe
                </Link>
              </li>
              <li>
                <Link href="/agendar" className="text-sidebar-foreground/70 transition-colors hover:text-sidebar-primary">
                  Agendar Horário
                </Link>
              </li>
              <li>
                <Link href="/contato" className="text-sidebar-foreground/70 transition-colors hover:text-sidebar-primary">
                  Contato
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h3 className="font-semibold">Contato</h3>
            <ul className="space-y-3 text-sm">
              <li className="flex items-start gap-2">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-sidebar-primary" />
                <span className="text-sidebar-foreground/70">
                  Av. Paulista, 1234 - Bela Vista<br />São Paulo - SP
                </span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-sidebar-primary" />
                <span className="text-sidebar-foreground/70">(11) 99999-9999</span>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 text-sidebar-primary" />
                <span className="text-sidebar-foreground/70">contato@malikshair.com.br</span>
              </li>
            </ul>
          </div>

          {/* Hours */}
          <div className="space-y-4">
            <h3 className="font-semibold">Horário de Funcionamento</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-sidebar-primary" />
                <span className="text-sidebar-foreground/70">Seg - Sex: 09h às 20h</span>
              </li>
              <li className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-sidebar-primary" />
                <span className="text-sidebar-foreground/70">Sábado: 09h às 18h</span>
              </li>
              <li className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-sidebar-primary" />
                <span className="text-sidebar-foreground/70">Domingo: Fechado</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 border-t border-sidebar-border pt-8 text-center text-sm text-sidebar-foreground/50">
          <p>&copy; 2026 Malik&apos;s Hair. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
