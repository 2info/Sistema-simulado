import { Card, CardContent } from '@/components/ui/card'
import { Star, Quote } from 'lucide-react'

const testimonials = [
  {
    name: 'Carolina Mendes',
    service: 'Coloração',
    rating: 5,
    text: 'Melhor salão que já fui! A Juliana fez um trabalho incrível nas minhas mechas. Super recomendo!',
    date: 'há 2 semanas'
  },
  {
    name: 'Roberto Silva',
    service: 'Corte Masculino',
    rating: 5,
    text: 'Atendimento impecável e ambiente muito agradável. O Carlos é um excelente profissional.',
    date: 'há 1 mês'
  },
  {
    name: 'Amanda Costa',
    service: 'Penteado Festa',
    rating: 5,
    text: 'Fiz meu penteado de casamento aqui e ficou perfeito! Equipe super atenciosa e dedicada.',
    date: 'há 3 semanas'
  }
]

export function TestimonialsSection() {
  return (
    <section className="bg-secondary/50 py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <span className="text-sm font-medium uppercase tracking-wider text-primary">
            Depoimentos
          </span>
          <h2 className="mt-2 font-serif text-3xl font-bold text-foreground md:text-4xl text-balance">
            O que nossos clientes dizem
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground text-pretty">
            A satisfação dos nossos clientes é nossa maior recompensa. 
            Veja o que eles têm a dizer sobre nossa experiência.
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-border/50 bg-background">
              <CardContent className="p-6">
                <Quote className="mb-4 h-8 w-8 text-primary/30" />
                <p className="mb-4 text-foreground">{testimonial.text}</p>
                <div className="mb-4 flex gap-0.5">
                  {Array.from({ length: testimonial.rating }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-foreground">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground">{testimonial.service}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">{testimonial.date}</span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
