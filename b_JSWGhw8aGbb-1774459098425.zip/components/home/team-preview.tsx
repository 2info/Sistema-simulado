"use client"

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { professionals } from '@/lib/data'
import { Star, ArrowRight } from 'lucide-react'

export function TeamPreview() {
  const featuredTeam = professionals.slice(0, 4)

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <span className="text-sm font-medium uppercase tracking-wider text-primary">
            Nossa Equipe
          </span>
          <h2 className="mt-2 font-serif text-3xl font-bold text-foreground md:text-4xl text-balance">
            Conheça nossos especialistas
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground text-pretty">
            Profissionais apaixonados pelo que fazem, sempre atualizados com as últimas 
            tendências e técnicas do mercado de beleza.
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {featuredTeam.map((professional) => (
            <Card 
              key={professional.id} 
              className="group overflow-hidden border-border/50 transition-all hover:border-primary/50 hover:shadow-lg"
            >
              <CardContent className="p-0">
                {/* Avatar */}
                <div className="relative aspect-square bg-gradient-to-br from-primary/20 to-accent/20">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="flex h-24 w-24 items-center justify-center rounded-full bg-background text-3xl font-bold text-primary">
                      {professional.name.split(' ').map(n => n[0]).join('')}
                    </div>
                  </div>
                </div>
                {/* Info */}
                <div className="p-5 text-center">
                  <h3 className="font-semibold text-foreground">{professional.name}</h3>
                  <p className="text-sm text-muted-foreground">{professional.role}</p>
                  <div className="mt-3 flex items-center justify-center gap-1">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-medium">{professional.rating}</span>
                    <span className="text-sm text-muted-foreground">
                      ({professional.reviews} avaliações)
                    </span>
                  </div>
                  <div className="mt-3 flex flex-wrap justify-center gap-1">
                    {professional.specialties.slice(0, 2).map((specialty, index) => (
                      <span 
                        key={index}
                        className="rounded-full bg-secondary px-2.5 py-0.5 text-xs text-secondary-foreground"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Button variant="outline" size="lg" asChild>
            <Link href="/equipe">
              Conhecer Toda a Equipe
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
