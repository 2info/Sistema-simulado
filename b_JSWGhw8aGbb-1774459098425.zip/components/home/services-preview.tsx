"use client"

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { services } from '@/lib/data'
import { ArrowRight, Clock } from 'lucide-react'

export function ServicesPreview() {
  const featuredServices = services.slice(0, 6)

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <span className="text-sm font-medium uppercase tracking-wider text-primary">
            Nossos Serviços
          </span>
          <h2 className="mt-2 font-serif text-3xl font-bold text-foreground md:text-4xl text-balance">
            Experiências personalizadas para você
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground text-pretty">
            Oferecemos uma ampla gama de serviços de beleza para atender todas as suas necessidades, 
            sempre com profissionais qualificados e produtos de alta qualidade.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featuredServices.map((service) => (
            <Card 
              key={service.id} 
              className="group overflow-hidden border-border/50 transition-all hover:border-primary/50 hover:shadow-lg"
            >
              <CardContent className="p-0">
                {/* Image placeholder */}
                <div className="relative aspect-[4/3] bg-gradient-to-br from-primary/10 to-accent/10">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="rounded-full bg-background/80 px-4 py-2 text-sm font-medium text-primary backdrop-blur-sm">
                      {service.category}
                    </div>
                  </div>
                </div>
                {/* Content */}
                <div className="p-5">
                  <div className="mb-3 flex items-start justify-between">
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                      {service.name}
                    </h3>
                    <span className="text-lg font-bold text-primary">
                      R$ {service.price}
                    </span>
                  </div>
                  <p className="mb-4 text-sm text-muted-foreground line-clamp-2">
                    {service.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      <span>{service.duration}</span>
                    </div>
                    <Link 
                      href={`/agendar?servico=${service.id}`}
                      className="flex items-center gap-1 text-sm font-medium text-primary hover:underline"
                    >
                      Agendar
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <Button variant="outline" size="lg" asChild>
            <Link href="/catalogo">
              Ver Todos os Serviços
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
