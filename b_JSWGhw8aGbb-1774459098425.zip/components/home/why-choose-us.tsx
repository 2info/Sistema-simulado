import { Award, Heart, Sparkles, Shield } from 'lucide-react'

const features = [
  {
    icon: Award,
    title: 'Profissionais Qualificados',
    description: 'Equipe de especialistas com anos de experiência e constante atualização.'
  },
  {
    icon: Sparkles,
    title: 'Produtos Premium',
    description: 'Utilizamos apenas produtos de alta qualidade das melhores marcas do mercado.'
  },
  {
    icon: Heart,
    title: 'Atendimento Personalizado',
    description: 'Cada cliente é único, e nosso atendimento é feito sob medida para você.'
  },
  {
    icon: Shield,
    title: 'Ambiente Seguro',
    description: 'Seguimos rigorosos protocolos de higiene e biossegurança.'
  }
]

export function WhyChooseUs() {
  return (
    <section className="bg-primary py-20 text-primary-foreground">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-12 text-center">
          <span className="text-sm font-medium uppercase tracking-wider text-primary-foreground/70">
            Por que nos escolher
          </span>
          <h2 className="mt-2 font-serif text-3xl font-bold md:text-4xl text-balance">
            Excelência em cada detalhe
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-primary-foreground/80 text-pretty">
            Nos dedicamos a proporcionar a melhor experiência em beleza e bem-estar, 
            sempre com qualidade e profissionalismo.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <div 
              key={index}
              className="group text-center"
            >
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary-foreground/10 transition-colors group-hover:bg-primary-foreground/20">
                <feature.icon className="h-8 w-8" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">{feature.title}</h3>
              <p className="text-sm text-primary-foreground/70">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
