import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Calendar, Phone } from 'lucide-react'

export function CTASection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-primary to-accent p-8 text-primary-foreground md:p-12 lg:p-16">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute -right-20 -top-20 h-64 w-64 rounded-full bg-white" />
            <div className="absolute -bottom-20 -left-20 h-64 w-64 rounded-full bg-white" />
          </div>
          
          <div className="relative z-10 mx-auto max-w-2xl text-center">
            <h2 className="font-serif text-3xl font-bold md:text-4xl lg:text-5xl text-balance">
              Pronto para transformar seu visual?
            </h2>
            <p className="mx-auto mt-4 max-w-lg text-primary-foreground/80 text-pretty">
              Agende seu horário agora e descubra por que somos o salão preferido de milhares de clientes.
            </p>
            <div className="mt-8 flex flex-col justify-center gap-4 sm:flex-row">
              <Button size="lg" variant="secondary" asChild className="text-base">
                <Link href="/agendar">
                  <Calendar className="mr-2 h-5 w-5" />
                  Agendar Online
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10 text-base">
                <a href="tel:+5511999999999">
                  <Phone className="mr-2 h-5 w-5" />
                  (11) 99999-9999
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
