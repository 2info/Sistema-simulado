export interface Service {
  id: string
  name: string
  description: string
  duration: string
  price: number
  category: string
  image: string
}

export interface Professional {
  id: string
  name: string
  role: string
  specialties: string[]
  image: string
  rating: number
  reviews: number
}

export const services: Service[] = [
  {
    id: '1',
    name: 'Corte Feminino',
    description: 'Corte personalizado de acordo com o formato do rosto e estilo pessoal',
    duration: '45 min',
    price: 120,
    category: 'Cortes',
    image: '/services/corte-feminino.jpg'
  },
  {
    id: '2',
    name: 'Corte Masculino',
    description: 'Corte moderno com acabamento perfeito e design personalizado',
    duration: '30 min',
    price: 80,
    category: 'Cortes',
    image: '/services/corte-masculino.jpg'
  },
  {
    id: '3',
    name: 'Coloração',
    description: 'Coloração profissional com produtos de alta qualidade',
    duration: '2h',
    price: 250,
    category: 'Coloração',
    image: '/services/coloracao.jpg'
  },
  {
    id: '4',
    name: 'Mechas e Luzes',
    description: 'Mechas naturais ou ousadas para iluminar seu visual',
    duration: '3h',
    price: 350,
    category: 'Coloração',
    image: '/services/mechas.jpg'
  },
  {
    id: '5',
    name: 'Escova Progressiva',
    description: 'Alisamento duradouro com tratamento nutritivo',
    duration: '3h',
    price: 400,
    category: 'Tratamentos',
    image: '/services/progressiva.jpg'
  },
  {
    id: '6',
    name: 'Hidratação Profunda',
    description: 'Tratamento intensivo para cabelos danificados',
    duration: '1h',
    price: 150,
    category: 'Tratamentos',
    image: '/services/hidratacao.jpg'
  },
  {
    id: '7',
    name: 'Penteado Festa',
    description: 'Penteados elegantes para ocasiões especiais',
    duration: '1h30',
    price: 200,
    category: 'Penteados',
    image: '/services/penteado.jpg'
  },
  {
    id: '8',
    name: 'Maquiagem',
    description: 'Maquiagem profissional para qualquer ocasião',
    duration: '1h',
    price: 180,
    category: 'Beleza',
    image: '/services/maquiagem.jpg'
  },
  {
    id: '9',
    name: 'Design de Sobrancelhas',
    description: 'Modelagem e design personalizado de sobrancelhas',
    duration: '30 min',
    price: 60,
    category: 'Beleza',
    image: '/services/sobrancelha.jpg'
  },
  {
    id: '10',
    name: 'Barba',
    description: 'Barba completa com toalha quente e produtos premium',
    duration: '30 min',
    price: 60,
    category: 'Masculino',
    image: '/services/barba.jpg'
  }
]

export const professionals: Professional[] = [
  {
    id: '1',
    name: 'Ana Paula',
    role: 'Cabeleireira Master',
    specialties: ['Cortes Femininos', 'Coloração', 'Mechas'],
    image: '/team/ana.jpg',
    rating: 4.9,
    reviews: 234
  },
  {
    id: '2',
    name: 'Carlos Eduardo',
    role: 'Barbeiro Senior',
    specialties: ['Cortes Masculinos', 'Barba', 'Pigmentação'],
    image: '/team/carlos.jpg',
    rating: 4.8,
    reviews: 187
  },
  {
    id: '3',
    name: 'Juliana Santos',
    role: 'Colorista',
    specialties: ['Coloração', 'Mechas', 'Luzes'],
    image: '/team/juliana.jpg',
    rating: 5.0,
    reviews: 156
  },
  {
    id: '4',
    name: 'Rafael Mendes',
    role: 'Hair Stylist',
    specialties: ['Penteados', 'Cortes', 'Tratamentos'],
    image: '/team/rafael.jpg',
    rating: 4.7,
    reviews: 203
  },
  {
    id: '5',
    name: 'Fernanda Lima',
    role: 'Maquiadora Profissional',
    specialties: ['Maquiagem', 'Design de Sobrancelhas'],
    image: '/team/fernanda.jpg',
    rating: 4.9,
    reviews: 145
  }
]

export const categories = [
  'Todos',
  'Cortes',
  'Coloração',
  'Tratamentos',
  'Penteados',
  'Beleza',
  'Masculino'
]

export const timeSlots = [
  '09:00', '09:30', '10:00', '10:30', '11:00', '11:30',
  '14:00', '14:30', '15:00', '15:30', '16:00', '16:30',
  '17:00', '17:30', '18:00', '18:30', '19:00', '19:30'
]
