"use client"

import { createContext, useContext, useState, ReactNode } from 'react'

export interface User {
  id: string
  name: string
  email: string
  phone: string
  avatar?: string
}

export interface Appointment {
  id: string
  userId: string
  serviceId: string
  serviceName: string
  professionalId: string
  professionalName: string
  date: string
  time: string
  price: number
  status: 'agendado' | 'confirmado' | 'concluido' | 'cancelado'
  createdAt: string
}

interface AuthContextType {
  user: User | null
  appointments: Appointment[]
  login: (email: string, password: string) => Promise<boolean>
  register: (name: string, email: string, phone: string, password: string) => Promise<boolean>
  logout: () => void
  addAppointment: (appointment: Omit<Appointment, 'id' | 'userId' | 'createdAt'>) => void
  cancelAppointment: (id: string) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Dados simulados de usuários
const mockUsers: (User & { password: string })[] = [
  {
    id: '1',
    name: 'Maria Silva',
    email: 'maria@email.com',
    phone: '(11) 99999-9999',
    password: '123456'
  }
]

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: '1',
      userId: '1',
      serviceId: '1',
      serviceName: 'Corte Feminino',
      professionalId: '1',
      professionalName: 'Ana Paula',
      date: '2026-03-28',
      time: '14:00',
      price: 120,
      status: 'confirmado',
      createdAt: '2026-03-20'
    }
  ])

  const login = async (email: string, password: string): Promise<boolean> => {
    const foundUser = mockUsers.find(u => u.email === email && u.password === password)
    if (foundUser) {
      const { password: _, ...userWithoutPassword } = foundUser
      setUser(userWithoutPassword)
      return true
    }
    return false
  }

  const register = async (name: string, email: string, phone: string, password: string): Promise<boolean> => {
    const exists = mockUsers.find(u => u.email === email)
    if (exists) return false

    const newUser: User & { password: string } = {
      id: String(mockUsers.length + 1),
      name,
      email,
      phone,
      password
    }
    mockUsers.push(newUser)
    const { password: _, ...userWithoutPassword } = newUser
    setUser(userWithoutPassword)
    return true
  }

  const logout = () => {
    setUser(null)
  }

  const addAppointment = (appointment: Omit<Appointment, 'id' | 'userId' | 'createdAt'>) => {
    if (!user) return
    const newAppointment: Appointment = {
      ...appointment,
      id: String(Date.now()),
      userId: user.id,
      createdAt: new Date().toISOString().split('T')[0]
    }
    setAppointments(prev => [...prev, newAppointment])
  }

  const cancelAppointment = (id: string) => {
    setAppointments(prev => 
      prev.map(apt => apt.id === id ? { ...apt, status: 'cancelado' } : apt)
    )
  }

  return (
    <AuthContext.Provider value={{ user, appointments, login, register, logout, addAppointment, cancelAppointment }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
