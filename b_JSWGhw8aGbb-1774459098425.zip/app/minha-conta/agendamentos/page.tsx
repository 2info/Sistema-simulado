"use client"

import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { AuthProvider, useAuth, Appointment } from '@/lib/auth-context'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Calendar, Clock, User, X, ChevronLeft, AlertCircle } from 'lucide-react'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

function AppointmentsContent() {
  const router = useRouter()
  const { user, appointments, cancelAppointment } = useAuth()
  const [filter, setFilter] = useState<'todos' | 'agendado' | 'confirmado' | 'concluido' | 'cancelado'>('todos')
  const [appointmentToCancel, setAppointmentToCancel] = useState<Appointment | null>(null)

  useEffect(() => {
    if (!user) {
      router.push('/login?redirect=/minha-conta/agendamentos')
    }
  }, [user, router])

  if (!user) {
    return (
      <div className="flex flex-1 items-center justify-center py-20">
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    )
  }

  const userAppointments = appointments.filter(apt => apt.userId === user.id)
  const filteredAppointments = filter === 'todos' 
    ? userAppointments 
    : userAppointments.filter(apt => apt.status === filter)

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmado': return 'bg-green-100 text-green-700'
      case 'agendado': return 'bg-yellow-100 text-yellow-700'
      case 'concluido': return 'bg-blue-100 text-blue-700'
      case 'cancelado': return 'bg-red-100 text-red-700'
      default: return 'bg-gray-100 text-gray-700'
    }
  }

  const handleCancelAppointment = () => {
    if (appointmentToCancel) {
      cancelAppointment(appointmentToCancel.id)
      setAppointmentToCancel(null)
    }
  }

  return (
    <main className="flex-1 bg-gradient-to-br from-primary/5 via-background to-accent/5 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" size="sm" asChild className="mb-4">
            <Link href="/minha-conta">
              <ChevronLeft className="mr-1 h-4 w-4" />
              Voltar
            </Link>
          </Button>
          <h1 className="font-serif text-3xl font-bold text-foreground">Meus Agendamentos</h1>
          <p className="mt-2 text-muted-foreground">Gerencie todos os seus agendamentos</p>
        </div>

        {/* Filters */}
        <div className="mb-6 flex flex-wrap gap-2">
          {[
            { value: 'todos', label: 'Todos' },
            { value: 'agendado', label: 'Agendados' },
            { value: 'confirmado', label: 'Confirmados' },
            { value: 'concluido', label: 'Concluídos' },
            { value: 'cancelado', label: 'Cancelados' }
          ].map((f) => (
            <Button
              key={f.value}
              variant={filter === f.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter(f.value as typeof filter)}
            >
              {f.label}
            </Button>
          ))}
        </div>

        {/* Appointments List */}
        {filteredAppointments.length === 0 ? (
          <Card>
            <CardContent className="py-12 text-center">
              <Calendar className="mx-auto mb-4 h-12 w-12 text-muted-foreground/50" />
              <p className="text-muted-foreground">
                {filter === 'todos' 
                  ? 'Você ainda não tem agendamentos' 
                  : `Nenhum agendamento ${filter}`}
              </p>
              <Button className="mt-4" asChild>
                <Link href="/agendar">Agendar Agora</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {filteredAppointments.map((apt) => (
              <Card key={apt.id} className={apt.status === 'cancelado' ? 'opacity-60' : ''}>
                <CardContent className="p-6">
                  <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                    <div className="flex items-start gap-4">
                      <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <Calendar className="h-7 w-7 text-primary" />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold">{apt.serviceName}</h3>
                        <div className="mt-1 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {new Date(apt.date).toLocaleDateString('pt-BR', {
                              weekday: 'long',
                              day: '2-digit',
                              month: 'long'
                            })} às {apt.time}
                          </span>
                          <span className="flex items-center gap-1">
                            <User className="h-4 w-4" />
                            {apt.professionalName}
                          </span>
                        </div>
                        <p className="mt-2 font-semibold text-primary">R$ {apt.price}</p>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <span className={`rounded-full px-3 py-1 text-sm font-medium ${getStatusColor(apt.status)}`}>
                        {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                      </span>
                      {(apt.status === 'agendado' || apt.status === 'confirmado') && (
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="text-destructive hover:text-destructive"
                          onClick={() => setAppointmentToCancel(apt)}
                        >
                          <X className="mr-1 h-4 w-4" />
                          Cancelar
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* CTA */}
        <div className="mt-8 text-center">
          <Button size="lg" asChild>
            <Link href="/agendar">
              <Calendar className="mr-2 h-4 w-4" />
              Novo Agendamento
            </Link>
          </Button>
        </div>
      </div>

      {/* Cancel Dialog */}
      <AlertDialog open={!!appointmentToCancel} onOpenChange={() => setAppointmentToCancel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              Cancelar Agendamento
            </AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja cancelar o agendamento de{' '}
              <strong>{appointmentToCancel?.serviceName}</strong> do dia{' '}
              <strong>
                {appointmentToCancel && new Date(appointmentToCancel.date).toLocaleDateString('pt-BR')}
              </strong>{' '}
              às <strong>{appointmentToCancel?.time}</strong>?
              <br /><br />
              Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Voltar</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleCancelAppointment}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Cancelar Agendamento
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  )
}

export default function AgendamentosPage() {
  return (
    <AuthProvider>
      <div className="flex min-h-screen flex-col">
        <Header />
        <AppointmentsContent />
        <Footer />
      </div>
    </AuthProvider>
  )
}
