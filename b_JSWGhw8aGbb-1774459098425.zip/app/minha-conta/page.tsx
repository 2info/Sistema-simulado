"use client"

import { useRouter } from 'next/navigation'
import { useEffect } from 'react'
import Link from 'next/link'
import { AuthProvider, useAuth } from '@/lib/auth-context'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Calendar, User, Clock, LogOut, ChevronRight, CalendarDays, Star } from 'lucide-react'

function AccountContent() {
  const router = useRouter()
  const { user, appointments, logout } = useAuth()

  useEffect(() => {
    if (!user) {
      router.push('/login?redirect=/minha-conta')
    }
  }, [user, router])

  if (!user) {
    return (
      <div className="flex flex-1 items-center justify-center py-20">
        <p className="text-muted-foreground">Carregando...</p>
      </div>
    )
  }

  const userAppointments = appointments.filter(apt => apt.userId === user.id)
  const upcomingAppointments = userAppointments.filter(apt => apt.status !== 'cancelado' && apt.status !== 'concluido')
  const completedAppointments = userAppointments.filter(apt => apt.status === 'concluido')

  return (
    <main className="flex-1 bg-gradient-to-br from-primary/5 via-background to-accent/5 py-12">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h1 className="font-serif text-3xl font-bold text-foreground">Minha Conta</h1>
          <p className="mt-2 text-muted-foreground">Gerencie suas informações e agendamentos</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Profile Card */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="text-lg">Perfil</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center text-center">
                <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-primary text-2xl font-bold text-primary-foreground">
                  {user.name.split(' ').map(n => n[0]).join('')}
                </div>
                <h3 className="text-lg font-semibold">{user.name}</h3>
                <p className="text-sm text-muted-foreground">{user.email}</p>
                <p className="text-sm text-muted-foreground">{user.phone}</p>
                
                <div className="mt-6 w-full space-y-2">
                  <Button variant="outline" className="w-full justify-between" asChild>
                    <Link href="/minha-conta/editar">
                      Editar Perfil
                      <ChevronRight className="h-4 w-4" />
                    </Link>
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full justify-between text-destructive hover:text-destructive"
                    onClick={logout}
                  >
                    Sair da Conta
                    <LogOut className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Stats and Quick Actions */}
          <div className="space-y-6 lg:col-span-2">
            {/* Stats */}
            <div className="grid gap-4 sm:grid-cols-3">
              <Card>
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                    <CalendarDays className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{upcomingAppointments.length}</p>
                    <p className="text-sm text-muted-foreground">Agendamentos</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                    <Clock className="h-6 w-6 text-green-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{completedAppointments.length}</p>
                    <p className="text-sm text-muted-foreground">Concluídos</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-yellow-100">
                    <Star className="h-6 w-6 text-yellow-600" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">VIP</p>
                    <p className="text-sm text-muted-foreground">Status</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Ações Rápidas</CardTitle>
              </CardHeader>
              <CardContent className="grid gap-3 sm:grid-cols-2">
                <Button asChild className="justify-start">
                  <Link href="/agendar">
                    <Calendar className="mr-2 h-4 w-4" />
                    Novo Agendamento
                  </Link>
                </Button>
                <Button variant="outline" asChild className="justify-start">
                  <Link href="/minha-conta/agendamentos">
                    <Clock className="mr-2 h-4 w-4" />
                    Ver Agendamentos
                  </Link>
                </Button>
                <Button variant="outline" asChild className="justify-start">
                  <Link href="/catalogo">
                    <Star className="mr-2 h-4 w-4" />
                    Ver Catálogo
                  </Link>
                </Button>
                <Button variant="outline" asChild className="justify-start">
                  <Link href="/minha-conta/editar">
                    <User className="mr-2 h-4 w-4" />
                    Editar Perfil
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* Recent Appointments */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-lg">Próximos Agendamentos</CardTitle>
                  <CardDescription>Seus agendamentos confirmados</CardDescription>
                </div>
                <Button variant="ghost" size="sm" asChild>
                  <Link href="/minha-conta/agendamentos">Ver todos</Link>
                </Button>
              </CardHeader>
              <CardContent>
                {upcomingAppointments.length === 0 ? (
                  <div className="py-8 text-center">
                    <Calendar className="mx-auto mb-4 h-12 w-12 text-muted-foreground/50" />
                    <p className="text-muted-foreground">Nenhum agendamento futuro</p>
                    <Button className="mt-4" asChild>
                      <Link href="/agendar">Agendar Agora</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {upcomingAppointments.slice(0, 3).map((apt) => (
                      <div key={apt.id} className="flex items-center justify-between rounded-lg border border-border p-4">
                        <div className="flex items-center gap-4">
                          <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                            <Calendar className="h-6 w-6 text-primary" />
                          </div>
                          <div>
                            <p className="font-semibold">{apt.serviceName}</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(apt.date).toLocaleDateString('pt-BR')} às {apt.time}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              com {apt.professionalName}
                            </p>
                          </div>
                        </div>
                        <span className={`rounded-full px-3 py-1 text-xs font-medium
                          ${apt.status === 'confirmado' ? 'bg-green-100 text-green-700' : 
                            apt.status === 'agendado' ? 'bg-yellow-100 text-yellow-700' : 
                            'bg-gray-100 text-gray-700'}
                        `}>
                          {apt.status.charAt(0).toUpperCase() + apt.status.slice(1)}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </main>
  )
}

export default function MinhaContaPage() {
  return (
    <AuthProvider>
      <div className="flex min-h-screen flex-col">
        <Header />
        <AccountContent />
        <Footer />
      </div>
    </AuthProvider>
  )
}
