"use client"

import { useState } from 'react'
import { AuthProvider } from '@/lib/auth-context'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { MapPin, Phone, Mail, Clock, Send, Check, Instagram, Facebook } from 'lucide-react'

export default function ContatoPage() {
  const [formState, setFormState] = useState<'idle' | 'loading' | 'success'>('idle')
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setFormState('loading')
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    setFormState('success')
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' })
    
    // Reset form after 3 seconds
    setTimeout(() => setFormState('idle'), 3000)
  }

  return (
    <AuthProvider>
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1">
          {/* Hero */}
          <section className="bg-gradient-to-br from-primary/5 via-background to-accent/5 py-16">
            <div className="container mx-auto px-4 text-center">
              <span className="text-sm font-medium uppercase tracking-wider text-primary">
                Contato
              </span>
              <h1 className="mt-2 font-serif text-4xl font-bold text-foreground md:text-5xl text-balance">
                Fale Conosco
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-muted-foreground text-pretty">
                Estamos sempre prontos para atendê-lo. Entre em contato por qualquer 
                um dos nossos canais ou venha nos visitar.
              </p>
            </div>
          </section>

          {/* Contact Section */}
          <section className="py-16">
            <div className="container mx-auto px-4">
              <div className="grid gap-8 lg:grid-cols-3">
                {/* Contact Info */}
                <div className="space-y-6">
                  <Card>
                    <CardContent className="flex items-start gap-4 p-6">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <MapPin className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">Endereço</h3>
                        <p className="mt-1 text-sm text-muted-foreground">
                          Av. Paulista, 1234<br />
                          Bela Vista - São Paulo, SP<br />
                          CEP: 01310-100
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="flex items-start gap-4 p-6">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <Phone className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">Telefone</h3>
                        <p className="mt-1 text-sm text-muted-foreground">
                          (11) 99999-9999<br />
                          (11) 3333-3333
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="flex items-start gap-4 p-6">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <Mail className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">E-mail</h3>
                        <p className="mt-1 text-sm text-muted-foreground">
                          contato@malikshair.com.br<br />
                          agendamentos@malikshair.com.br
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardContent className="flex items-start gap-4 p-6">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary/10">
                        <Clock className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">Horário de Funcionamento</h3>
                        <p className="mt-1 text-sm text-muted-foreground">
                          Seg - Sex: 09h às 20h<br />
                          Sábado: 09h às 18h<br />
                          Domingo: Fechado
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Social Media */}
                  <Card>
                    <CardContent className="p-6">
                      <h3 className="mb-4 font-semibold text-foreground">Siga-nos</h3>
                      <div className="flex gap-3">
                        <Button variant="outline" size="icon" asChild>
                          <a href="#" target="_blank" rel="noopener noreferrer">
                            <Instagram className="h-5 w-5" />
                          </a>
                        </Button>
                        <Button variant="outline" size="icon" asChild>
                          <a href="#" target="_blank" rel="noopener noreferrer">
                            <Facebook className="h-5 w-5" />
                          </a>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Contact Form */}
                <div className="lg:col-span-2">
                  <Card>
                    <CardHeader>
                      <CardTitle>Envie sua mensagem</CardTitle>
                      <CardDescription>
                        Preencha o formulário abaixo e entraremos em contato em breve.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      {formState === 'success' ? (
                        <div className="py-12 text-center">
                          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-green-100">
                            <Check className="h-8 w-8 text-green-600" />
                          </div>
                          <h3 className="text-lg font-semibold text-foreground">Mensagem enviada!</h3>
                          <p className="mt-2 text-muted-foreground">
                            Obrigado pelo contato. Responderemos em breve.
                          </p>
                        </div>
                      ) : (
                        <form onSubmit={handleSubmit} className="space-y-4">
                          <div className="grid gap-4 sm:grid-cols-2">
                            <div className="space-y-2">
                              <Label htmlFor="name">Nome completo</Label>
                              <Input
                                id="name"
                                placeholder="Seu nome"
                                value={formData.name}
                                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                                required
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="email">E-mail</Label>
                              <Input
                                id="email"
                                type="email"
                                placeholder="seu@email.com"
                                value={formData.email}
                                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                                required
                              />
                            </div>
                          </div>
                          <div className="grid gap-4 sm:grid-cols-2">
                            <div className="space-y-2">
                              <Label htmlFor="phone">Telefone</Label>
                              <Input
                                id="phone"
                                type="tel"
                                placeholder="(11) 99999-9999"
                                value={formData.phone}
                                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="subject">Assunto</Label>
                              <Input
                                id="subject"
                                placeholder="Como podemos ajudar?"
                                value={formData.subject}
                                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                                required
                              />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="message">Mensagem</Label>
                            <Textarea
                              id="message"
                              placeholder="Escreva sua mensagem aqui..."
                              rows={5}
                              value={formData.message}
                              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                              required
                            />
                          </div>
                          <Button type="submit" className="w-full" disabled={formState === 'loading'}>
                            {formState === 'loading' ? (
                              'Enviando...'
                            ) : (
                              <>
                                <Send className="mr-2 h-4 w-4" />
                                Enviar Mensagem
                              </>
                            )}
                          </Button>
                        </form>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </section>

          {/* Map */}
          <section className="border-t border-border">
            <div className="container mx-auto px-4 py-8">
              <div className="aspect-[21/9] overflow-hidden rounded-xl bg-secondary">
                <div className="flex h-full items-center justify-center">
                  <div className="text-center">
                    <MapPin className="mx-auto mb-4 h-12 w-12 text-primary/50" />
                    <p className="text-muted-foreground">
                      Mapa interativo - Av. Paulista, 1234
                    </p>
                    <Button variant="outline" className="mt-4" asChild>
                      <a 
                        href="https://www.google.com/maps/search/Av.+Paulista,+1234" 
                        target="_blank" 
                        rel="noopener noreferrer"
                      >
                        Abrir no Google Maps
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </section>
        </main>
        <Footer />
      </div>
    </AuthProvider>
  )
}
