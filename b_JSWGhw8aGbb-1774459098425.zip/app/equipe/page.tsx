"use client"

import Link from 'next/link'
import { AuthProvider } from '@/lib/auth-context'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { professionals } from '@/lib/data'
import { Star, Calendar, Instagram } from 'lucide-react'

export default function EquipePage() {
  return (
    <AuthProvider>
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1">
          {/* Hero */}
          <section className="bg-gradient-to-br from-primary/5 via-background to-accent/5 py-16">
            <div className="container mx-auto px-4 text-center">
              <span className="text-sm font-medium uppercase tracking-wider text-primary">
                Nossa Equipe
              </span>
              <h1 className="mt-2 font-serif text-4xl font-bold text-foreground md:text-5xl text-balance">
                Conheça Nossos Especialistas
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-muted-foreground text-pretty">
                Uma equipe apaixonada por beleza, sempre atualizada com as últimas tendências 
                e pronta para transformar seu visual.
              </p>
            </div>
          </section>

          {/* Team Grid */}
          <section className="py-16">
            <div className="container mx-auto px-4">
              <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
                {professionals.map((professional) => (
                  <Card 
                    key={professional.id} 
                    className="group overflow-hidden border-border/50 transition-all hover:border-primary/50 hover:shadow-xl"
                  >
                    <CardContent className="p-0">
                      {/* Avatar */}
                      <div className="relative aspect-[4/3] bg-gradient-to-br from-primary/20 to-accent/20">
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="flex h-32 w-32 items-center justify-center rounded-full bg-background text-4xl font-bold text-primary shadow-lg">
                            {professional.name.split(' ').map(n => n[0]).join('')}
                          </div>
                        </div>
                        {/* Social Links */}
                        <div className="absolute right-4 top-4">
                          <Button variant="secondary" size="icon" className="h-9 w-9">
                            <Instagram className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      {/* Info */}
                      <div className="p-6">
                        <div className="mb-4 text-center">
                          <h3 className="text-xl font-semibold text-foreground">{professional.name}</h3>
                          <p className="text-primary">{professional.role}</p>
                        </div>
                        
                        {/* Rating */}
                        <div className="mb-4 flex items-center justify-center gap-2">
                          <div className="flex gap-0.5">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star 
                                key={i} 
                                className={`h-4 w-4 ${i < Math.floor(professional.rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-200'}`} 
                              />
                            ))}
                          </div>
                          <span className="text-sm font-medium">{professional.rating}</span>
                          <span className="text-sm text-muted-foreground">
                            ({professional.reviews} avaliações)
                          </span>
                        </div>

                        {/* Specialties */}
                        <div className="mb-6">
                          <p className="mb-2 text-center text-sm text-muted-foreground">Especialidades:</p>
                          <div className="flex flex-wrap justify-center gap-2">
                            {professional.specialties.map((specialty, index) => (
                              <span 
                                key={index}
                                className="rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground"
                              >
                                {specialty}
                              </span>
                            ))}
                          </div>
                        </div>

                        {/* CTA */}
                        <Button className="w-full" asChild>
                          <Link href={`/agendar?profissional=${professional.id}`}>
                            <Calendar className="mr-2 h-4 w-4" />
                            Agendar com {professional.name.split(' ')[0]}
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>

          {/* Join Team CTA */}
          <section className="border-t border-border bg-secondary/30 py-16">
            <div className="container mx-auto px-4 text-center">
              <h2 className="font-serif text-2xl font-bold text-foreground md:text-3xl">
                Quer fazer parte do nosso time?
              </h2>
              <p className="mx-auto mt-4 max-w-lg text-muted-foreground">
                Estamos sempre em busca de talentos apaixonados por beleza. 
                Se você é um profissional qualificado, entre em contato conosco.
              </p>
              <Button className="mt-6" asChild>
                <Link href="/contato">
                  Enviar Currículo
                </Link>
              </Button>
            </div>
          </section>
        </main>
        <Footer />
      </div>
    </AuthProvider>
  )
}
