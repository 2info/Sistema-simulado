"use client"

import { AuthProvider } from '@/lib/auth-context'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { HeroSection } from '@/components/home/hero-section'
import { ServicesPreview } from '@/components/home/services-preview'
import { WhyChooseUs } from '@/components/home/why-choose-us'
import { TeamPreview } from '@/components/home/team-preview'
import { TestimonialsSection } from '@/components/home/testimonials-section'
import { CTASection } from '@/components/home/cta-section'

export default function HomePage() {
  return (
    <AuthProvider>
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1">
          <HeroSection />
          <ServicesPreview />
          <WhyChooseUs />
          <TeamPreview />
          <TestimonialsSection />
          <CTASection />
        </main>
        <Footer />
      </div>
    </AuthProvider>
  )
}
