"use client"

import { useState } from 'react'
import { AuthProvider } from '@/lib/auth-context'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { services, categories } from '@/lib/data'
import { Search, Clock, ArrowRight } from 'lucide-react'
import Link from 'next/link'

export default function CatalogoPage() {
  const [selectedCategory, setSelectedCategory] = useState('Todos')
  const [searchQuery, setSearchQuery] = useState('')

  const filteredServices = services.filter((service) => {
    const matchesCategory = selectedCategory === 'Todos' || service.category === selectedCategory
    const matchesSearch = service.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         service.description.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <AuthProvider>
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1">
          {/* Hero */}
          <section className="bg-gradient-to-br from-primary/5 via-background to-accent/5 py-16">
            <div className="container mx-auto px-4 text-center">
              <span className="text-sm font-medium uppercase tracking-wider text-primary">
                Catálogo
              </span>
              <h1 className="mt-2 font-serif text-4xl font-bold text-foreground md:text-5xl text-balance">
                Nossos Serviços
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-muted-foreground text-pretty">
                Descubra nossa ampla gama de serviços de beleza e bem-estar, 
                todos realizados por profissionais qualificados.
              </p>
            </div>
          </section>

          {/* Filters */}
          <section className="border-b border-border bg-background py-6">
            <div className="container mx-auto px-4">
              <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                {/* Search */}
                <div className="relative max-w-sm flex-1">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Buscar serviços..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>

                {/* Categories */}
                <div className="flex flex-wrap gap-2">
                  {categories.map((category) => (
                    <Button
                      key={category}
                      variant={selectedCategory === category ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedCategory(category)}
                    >
                      {category}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          </section>

          {/* Services Grid */}
          <section className="py-12">
            <div className="container mx-auto px-4">
              {filteredServices.length === 0 ? (
                <div className="py-12 text-center">
                  <p className="text-muted-foreground">
                    Nenhum serviço encontrado para sua busca.
                  </p>
                </div>
              ) : (
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                  {filteredServices.map((service) => (
                    <Card 
                      key={service.id} 
                      className="group overflow-hidden border-border/50 transition-all hover:border-primary/50 hover:shadow-lg"
                    >
                      <CardContent className="p-0">
                        {/* Image placeholder */}
                        <div className="relative aspect-[4/3] bg-gradient-to-br from-primary/10 to-accent/10">
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="rounded-full bg-background/80 px-4 py-2 text-sm font-medium text-primary backdrop-blur-sm">
                              {service.category}
                            </div>
                          </div>
                        </div>
                        {/* Content */}
                        <div className="p-5">
                          <div className="mb-3 flex items-start justify-between">
                            <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors">
                              {service.name}
                            </h3>
                            <span className="text-lg font-bold text-primary">
                              R$ {service.price}
                            </span>
                          </div>
                          <p className="mb-4 text-sm text-muted-foreground line-clamp-2">
                            {service.description}
                          </p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
                              <Clock className="h-4 w-4" />
                              <span>{service.duration}</span>
                            </div>
                            <Link 
                              href={`/agendar?servico=${service.id}`}
                              className="flex items-center gap-1 text-sm font-medium text-primary hover:underline"
                            >
                              Agendar
                              <ArrowRight className="h-4 w-4" />
                            </Link>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          </section>
        </main>
        <Footer />
      </div>
    </AuthProvider>
  )
}
