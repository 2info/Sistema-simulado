"use client"

import { useState, useEffect, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import { AuthProvider, useAuth } from '@/lib/auth-context'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { services, professionals, timeSlots, Service, Professional } from '@/lib/data'
import { Calendar, Clock, User, Check, ChevronRight, ChevronLeft, ArrowRight } from 'lucide-react'
import Link from 'next/link'

function BookingContent() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const { user, addAppointment } = useAuth()
  
  const [step, setStep] = useState(1)
  const [selectedService, setSelectedService] = useState<Service | null>(null)
  const [selectedProfessional, setSelectedProfessional] = useState<Professional | null>(null)
  const [selectedDate, setSelectedDate] = useState<string>('')
  const [selectedTime, setSelectedTime] = useState<string>('')
  const [bookingComplete, setBookingComplete] = useState(false)

  // Check for service in URL params
  useEffect(() => {
    const serviceId = searchParams.get('servico')
    if (serviceId) {
      const service = services.find(s => s.id === serviceId)
      if (service) {
        setSelectedService(service)
        setStep(2)
      }
    }
  }, [searchParams])

  // Generate next 14 days
  const getAvailableDates = () => {
    const dates = []
    const today = new Date()
    for (let i = 1; i <= 14; i++) {
      const date = new Date(today)
      date.setDate(today.getDate() + i)
      // Skip Sundays
      if (date.getDay() !== 0) {
        dates.push(date)
      }
    }
    return dates
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: 'short' })
  }

  const formatDateISO = (date: Date) => {
    return date.toISOString().split('T')[0]
  }

  const handleConfirmBooking = () => {
    if (!user) {
      router.push('/login?redirect=/agendar')
      return
    }

    if (selectedService && selectedProfessional && selectedDate && selectedTime) {
      addAppointment({
        serviceId: selectedService.id,
        serviceName: selectedService.name,
        professionalId: selectedProfessional.id,
        professionalName: selectedProfessional.name,
        date: selectedDate,
        time: selectedTime,
        price: selectedService.price,
        status: 'agendado'
      })
      setBookingComplete(true)
    }
  }

  // Success screen
  if (bookingComplete) {
    return (
      <div className="container mx-auto max-w-2xl px-4 py-20">
        <Card className="text-center">
          <CardContent className="py-12">
            <div className="mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-full bg-green-100">
              <Check className="h-10 w-10 text-green-600" />
            </div>
            <h2 className="mb-2 font-serif text-2xl font-bold text-foreground">
              Agendamento Confirmado!
            </h2>
            <p className="mb-6 text-muted-foreground">
              Seu horário foi reservado com sucesso. Você receberá uma confirmação por e-mail.
            </p>
            <div className="mb-8 rounded-lg bg-secondary p-4 text-left">
              <div className="space-y-2 text-sm">
                <p><strong>Serviço:</strong> {selectedService?.name}</p>
                <p><strong>Profissional:</strong> {selectedProfessional?.name}</p>
                <p><strong>Data:</strong> {selectedDate && new Date(selectedDate).toLocaleDateString('pt-BR', { 
                  weekday: 'long', 
                  day: '2-digit', 
                  month: 'long', 
                  year: 'numeric' 
                })}</p>
                <p><strong>Horário:</strong> {selectedTime}</p>
                <p><strong>Valor:</strong> R$ {selectedService?.price}</p>
              </div>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row sm:justify-center">
              <Button asChild>
                <Link href="/minha-conta/agendamentos">Ver Meus Agendamentos</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/">Voltar ao Início</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Progress Steps */}
      <div className="mb-12">
        <div className="mx-auto max-w-2xl">
          <div className="flex items-center justify-between">
            {[
              { num: 1, label: 'Serviço' },
              { num: 2, label: 'Profissional' },
              { num: 3, label: 'Data e Hora' },
              { num: 4, label: 'Confirmação' }
            ].map((s, index) => (
              <div key={s.num} className="flex items-center">
                <div className="flex flex-col items-center">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-full text-sm font-medium transition-colors
                    ${step >= s.num ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground'}
                  `}>
                    {step > s.num ? <Check className="h-5 w-5" /> : s.num}
                  </div>
                  <span className={`mt-2 text-xs ${step >= s.num ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                    {s.label}
                  </span>
                </div>
                {index < 3 && (
                  <div className={`mx-2 h-0.5 w-8 md:w-16 lg:w-24 transition-colors
                    ${step > s.num ? 'bg-primary' : 'bg-border'}
                  `} />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Step 1: Select Service */}
      {step === 1 && (
        <div>
          <div className="mb-8 text-center">
            <h2 className="font-serif text-2xl font-bold text-foreground">Escolha o Serviço</h2>
            <p className="mt-2 text-muted-foreground">Selecione o serviço que deseja realizar</p>
          </div>
          <div className="mx-auto grid max-w-4xl gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service) => (
              <Card 
                key={service.id}
                className={`cursor-pointer transition-all hover:border-primary/50 hover:shadow-md
                  ${selectedService?.id === service.id ? 'border-primary ring-2 ring-primary/20' : 'border-border/50'}
                `}
                onClick={() => setSelectedService(service)}
              >
                <CardContent className="p-4">
                  <div className="mb-2 flex items-start justify-between">
                    <span className="rounded-full bg-primary/10 px-2 py-0.5 text-xs font-medium text-primary">
                      {service.category}
                    </span>
                    <span className="font-bold text-primary">R$ {service.price}</span>
                  </div>
                  <h3 className="font-semibold text-foreground">{service.name}</h3>
                  <p className="mt-1 text-sm text-muted-foreground line-clamp-2">{service.description}</p>
                  <div className="mt-3 flex items-center gap-1 text-sm text-muted-foreground">
                    <Clock className="h-4 w-4" />
                    <span>{service.duration}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="mt-8 flex justify-center">
            <Button 
              size="lg" 
              disabled={!selectedService}
              onClick={() => setStep(2)}
            >
              Continuar
              <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 2: Select Professional */}
      {step === 2 && (
        <div>
          <div className="mb-8 text-center">
            <h2 className="font-serif text-2xl font-bold text-foreground">Escolha o Profissional</h2>
            <p className="mt-2 text-muted-foreground">Selecione o profissional de sua preferência</p>
          </div>
          <div className="mx-auto grid max-w-3xl gap-4 sm:grid-cols-2">
            {professionals.map((professional) => (
              <Card 
                key={professional.id}
                className={`cursor-pointer transition-all hover:border-primary/50 hover:shadow-md
                  ${selectedProfessional?.id === professional.id ? 'border-primary ring-2 ring-primary/20' : 'border-border/50'}
                `}
                onClick={() => setSelectedProfessional(professional)}
              >
                <CardContent className="flex items-center gap-4 p-4">
                  <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xl font-bold text-primary">
                    {professional.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground">{professional.name}</h3>
                    <p className="text-sm text-muted-foreground">{professional.role}</p>
                    <div className="mt-1 flex items-center gap-1 text-sm">
                      <span className="text-yellow-500">★</span>
                      <span className="font-medium">{professional.rating}</span>
                      <span className="text-muted-foreground">({professional.reviews})</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="mt-8 flex justify-center gap-4">
            <Button variant="outline" size="lg" onClick={() => setStep(1)}>
              <ChevronLeft className="mr-2 h-4 w-4" />
              Voltar
            </Button>
            <Button 
              size="lg" 
              disabled={!selectedProfessional}
              onClick={() => setStep(3)}
            >
              Continuar
              <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 3: Select Date and Time */}
      {step === 3 && (
        <div>
          <div className="mb-8 text-center">
            <h2 className="font-serif text-2xl font-bold text-foreground">Escolha Data e Horário</h2>
            <p className="mt-2 text-muted-foreground">Selecione o melhor dia e horário para você</p>
          </div>
          <div className="mx-auto max-w-2xl">
            {/* Date Selection */}
            <div className="mb-8">
              <h3 className="mb-4 font-semibold text-foreground">Data</h3>
              <div className="flex flex-wrap gap-2">
                {getAvailableDates().map((date) => (
                  <Button
                    key={date.toISOString()}
                    variant={selectedDate === formatDateISO(date) ? 'default' : 'outline'}
                    className="min-w-[100px]"
                    onClick={() => setSelectedDate(formatDateISO(date))}
                  >
                    {formatDate(date)}
                  </Button>
                ))}
              </div>
            </div>

            {/* Time Selection */}
            {selectedDate && (
              <div>
                <h3 className="mb-4 font-semibold text-foreground">Horário</h3>
                <div className="grid grid-cols-4 gap-2 sm:grid-cols-6">
                  {timeSlots.map((time) => (
                    <Button
                      key={time}
                      variant={selectedTime === time ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => setSelectedTime(time)}
                    >
                      {time}
                    </Button>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="mt-8 flex justify-center gap-4">
            <Button variant="outline" size="lg" onClick={() => setStep(2)}>
              <ChevronLeft className="mr-2 h-4 w-4" />
              Voltar
            </Button>
            <Button 
              size="lg" 
              disabled={!selectedDate || !selectedTime}
              onClick={() => setStep(4)}
            >
              Continuar
              <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}

      {/* Step 4: Confirmation */}
      {step === 4 && (
        <div>
          <div className="mb-8 text-center">
            <h2 className="font-serif text-2xl font-bold text-foreground">Confirme seu Agendamento</h2>
            <p className="mt-2 text-muted-foreground">Revise os detalhes antes de confirmar</p>
          </div>
          <Card className="mx-auto max-w-lg">
            <CardHeader>
              <CardTitle>Resumo do Agendamento</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3 rounded-lg bg-secondary p-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                  <Calendar className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Serviço</p>
                  <p className="font-semibold">{selectedService?.name}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-lg bg-secondary p-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                  <User className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Profissional</p>
                  <p className="font-semibold">{selectedProfessional?.name}</p>
                </div>
              </div>
              <div className="flex items-center gap-3 rounded-lg bg-secondary p-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                  <Clock className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Data e Horário</p>
                  <p className="font-semibold">
                    {selectedDate && new Date(selectedDate).toLocaleDateString('pt-BR', { 
                      weekday: 'long', 
                      day: '2-digit', 
                      month: 'long' 
                    })} às {selectedTime}
                  </p>
                </div>
              </div>
              <div className="border-t border-border pt-4">
                <div className="flex justify-between text-lg">
                  <span className="font-semibold">Total</span>
                  <span className="font-bold text-primary">R$ {selectedService?.price}</span>
                </div>
              </div>
              {!user && (
                <div className="rounded-lg bg-yellow-50 p-3 text-sm text-yellow-800">
                  <p>Você precisa estar logado para confirmar o agendamento.</p>
                </div>
              )}
            </CardContent>
          </Card>
          <div className="mt-8 flex justify-center gap-4">
            <Button variant="outline" size="lg" onClick={() => setStep(3)}>
              <ChevronLeft className="mr-2 h-4 w-4" />
              Voltar
            </Button>
            <Button size="lg" onClick={handleConfirmBooking}>
              {user ? 'Confirmar Agendamento' : 'Fazer Login e Confirmar'}
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

export default function AgendarPage() {
  return (
    <AuthProvider>
      <div className="flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 bg-gradient-to-br from-primary/5 via-background to-accent/5">
          {/* Hero */}
          <section className="border-b border-border bg-background py-12">
            <div className="container mx-auto px-4 text-center">
              <span className="text-sm font-medium uppercase tracking-wider text-primary">
                Agendamento
              </span>
              <h1 className="mt-2 font-serif text-3xl font-bold text-foreground md:text-4xl text-balance">
                Agende seu Horário
              </h1>
              <p className="mx-auto mt-4 max-w-xl text-muted-foreground text-pretty">
                Escolha o serviço, profissional e horário que melhor se adapta à sua agenda.
              </p>
            </div>
          </section>

          <Suspense fallback={<div className="py-20 text-center">Carregando...</div>}>
            <BookingContent />
          </Suspense>
        </main>
        <Footer />
      </div>
    </AuthProvider>
  )
}
